// Script de autenticação e logout

// Configurar logout em todos os botões com classe .btn-logout
document.addEventListener('DOMContentLoaded', function() {
    const botoesLogout = document.querySelectorAll('.btn-logout');
    
    botoesLogout.forEach(botao => {
        botao.addEventListener('click', function(event) {
            // event.preventDefault(); // Já vai redirecionar naturalmente para index.html
            localStorage.removeItem('usuarioLogado');
            localStorage.removeItem('perfilLogado');
        });
    });
});
